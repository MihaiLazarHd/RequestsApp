﻿using Bogus;
using Bogus.Extensions;
using System;
using System.Collections.Generic;
using System.Configuration;
using System.Linq;
using System.Net;
using System.Net.Http;
using System.Net.Http.Headers;
using System.Text;
using System.Threading.Tasks;

namespace RequestsAppConsole
{
    class Program
    {
        static HttpClient client = new HttpClient();
        static uint requestsNo = 100;

        static void Main(string[] args)
        {
            uint result;

            if (args.Length > 0 && uint.TryParse(args[0], out result))
                requestsNo = result;

            RunAsync().GetAwaiter().GetResult();
        }

        static async Task RunAsync()
        {
            // Update port # in the following line.
            client.BaseAddress = new Uri(ConfigurationManager.AppSettings["WebApiUrl"]);
            client.DefaultRequestHeaders.Accept.Clear();
            client.DefaultRequestHeaders.Accept.Add(
                new MediaTypeWithQualityHeaderValue("application/json"));

            try
            {
                var requests = new List<Request>();
                for (int i = 0; i < requestsNo; i++)
                {
                    requests.Add(new Faker<Request>()
                        .RuleFor(a => a.Index, b => b.IndexGlobal + 1)
                        .RuleFor(a => a.Name, b => b.Name.FullName())
                        .RuleFor(a => a.Visits, b => new Bogus.Randomizer().Number(1, 100).OrNull(b, 0.02f))
                        .RuleFor(a => a.Date, b => b.Date.Between(new DateTime(2018, 12, 1), new DateTime(2018, 12, 31)))
                        .Generate());
                }

                var result = await CreateRequestsAsync(requests);
                Console.WriteLine(result.ToString());

            }
            catch (Exception e)
            {
                Console.WriteLine(e.Message);
            }

            Console.ReadLine();
        }

        static async Task<HttpStatusCode> CreateRequestsAsync(List<Request> request)
        {
            HttpResponseMessage response = await client.PostAsJsonAsync(
                "api/data", request);
            response.EnsureSuccessStatusCode();

            // return URI of the created resource.
            return response.StatusCode;
        }
    }
}
