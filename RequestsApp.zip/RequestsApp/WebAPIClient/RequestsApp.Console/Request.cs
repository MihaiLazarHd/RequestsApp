﻿using Newtonsoft.Json;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Xml.Serialization;

namespace RequestsAppConsole
{
    public class Request
    {
        [JsonProperty(PropertyName = "ix")]
        public int Index { get; set; }

        public string Name { get; set; }

        public int? Visits { get; set; }

        public DateTime Date { get; set; }

    }

}
