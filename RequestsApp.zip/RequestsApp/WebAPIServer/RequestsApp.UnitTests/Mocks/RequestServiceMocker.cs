﻿using RequestsApp.Interfaces;
using RequestsApp.Repositories;
using RequestsApp.Services;
using System;
using System.Collections.Generic;
using System.Text;

namespace RequestsApp.UnitTests.Mocks
{
    public static class RequestServiceMocker
    {
        public static IRequestsService GetRequestsService(string dbName)
           => new RequestsService(new RequestsRepository(DbContextMocker.GetDbContextInMemory(dbName))
           );
    }
}
