﻿using RequestsApp.Models;
using System;
using System.Collections.Generic;
using System.Text;

namespace RequestsApp.UnitTests.Mocks
{
    public static class DBContextExtensions
    {
        public static void SeedInMemory(this RequestDBContext dbContext)
        {
            var requests = new List<Request>()
            {
                new Request() { Index=1, Name="product original 1", Visits=4, Date=new DateTime(2018,12,21)},
                new Request() { Index=2, Name="product original 2", Visits=3, Date=new DateTime(2018,12,22)}
            };

            dbContext.Requests.AddRange(requests);

            dbContext.SaveChanges();
        }
    }
}
