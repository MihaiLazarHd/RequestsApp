﻿using Microsoft.EntityFrameworkCore;
using Microsoft.EntityFrameworkCore.Diagnostics;
using System;
using System.Collections.Generic;
using System.Text;

namespace RequestsApp.UnitTests.Mocks
{
    public static class DbContextMocker
    {
        public static RequestDBContext GetDbContextInMemory(string dbName)
        {
            // Create options for DbContext
            // Use in memory provider
            // Disable transactions because in memory database doesn't support txns
            var options = new DbContextOptionsBuilder<RequestDBContext>()
                .UseInMemoryDatabase(databaseName: dbName)
                .ConfigureWarnings(w => w.Ignore(InMemoryEventId.TransactionIgnoredWarning))
                .Options;

            var dbContext = new RequestDBContext(options);

            // Seed data for DbContext instance
            dbContext.SeedInMemory();

            return dbContext;
        }
    }
}
