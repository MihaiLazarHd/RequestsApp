using Microsoft.AspNetCore.Mvc;
using RequestsApp.Controllers;
using RequestsApp.Models;
using RequestsApp.UnitTests.Mocks;
using System;
using System.Collections.Generic;
using System.Threading.Tasks;
using Xunit;

namespace RequestsApp.UnitTests
{
    public class RequestsTests
    {
        [Fact]
        public async Task TestProcessRequestsAsync()
        {
            // Arrange
            var service = RequestServiceMocker.GetRequestsService("RequestDB");
            var controller = new DataController(service);
            var requests = new List<Request>
            {
                new Request() { Index=1001, Name="product nonexistant 1", Visits=null, Date=new DateTime(2018,12,21)},
                new Request() { Index=1002, Name="product nonexistant 2", Visits=11, Date=new DateTime(2018,12,21)}
            };

            // Act
            var response = await controller.ProcessRequestsAsync(requests) as ObjectResult;
            var value = response.Value as List<Request>;

            // Assert
            Assert.True(response.StatusCode == 200);
            Assert.True(value.Count == 2);
        }

        [Fact]
        public async Task TestSaveFilesAsync()
        {
            // Arrange
            var service = RequestServiceMocker.GetRequestsService("RequestDB");
            var controller = new JobsController(service);

            // Act
            var response = await controller.SaveFilesAsync() as ObjectResult;
            var value = response.Value as List<Request>;

            // Assert
            Assert.True(response.StatusCode == 200);
            Assert.True(value.Count == 2);
        }

    }
}
