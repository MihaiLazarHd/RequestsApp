using RequestsApp.IntegrationTests.Helpers;
using RequestsApp.Models;
using System;
using System.Collections.Generic;
using System.Net.Http;
using System.Threading.Tasks;
using Xunit;

namespace RequestsApp.IntegrationTests
{
    public class RequestsTests : IClassFixture<TestFixture<Startup>>
    {
        private HttpClient apiClient;

        public RequestsTests(TestFixture<Startup> fixture)
        {
            apiClient = fixture.Client;
        }

        [Fact]
        public async Task TestProcessRequestsAsync()
        {
            // Arrange
            var request = new
            {
                Url = "/api/data",
                Body = new List<Request>()
                {
                    new Request() { Index=1001,Name="product 1",Visits=null,Date=new DateTime(2018,12,21)},
                    new Request() { Index=1002,Name="product 2",Visits=11,Date=new DateTime(2018,12,21)}
                }
            };

            // Act
            var response = await apiClient.PostAsync(request.Url, ContentHelper.GetStringContent(request.Body));

            // Assert
            response.EnsureSuccessStatusCode();
        }

        [Fact]
        public async Task TestSaveFilesAsync()
        {
            // Arrange
            var request = new
            {
                Url = "/api/jobs/saveFiles"
            };

            // Act
            var response = await apiClient.GetAsync(request.Url);

            // Assert
            response.EnsureSuccessStatusCode();
        }

    }
}
