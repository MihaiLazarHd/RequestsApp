﻿using Microsoft.AspNetCore.Mvc;
using RequestsApp.Interfaces;
using RequestsApp.Models;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Net;
using System.Threading.Tasks;

namespace RequestsApp.Services
{
    public class RequestsService: IRequestsService
    {
        private readonly IRequestsRepository _requestsRepository;

        public RequestsService(IRequestsRepository requestsRepository)
        {
            _requestsRepository = requestsRepository;
        }

        public async Task<IActionResult> ProcessRequestsAsync(List<Request> input)
        {
            var response = await _requestsRepository.ProcessRequestsAsync(input);

            var status = HttpStatusCode.OK;
            if (response == null)
                status = HttpStatusCode.InternalServerError;
            else if (!response.Any())
                status = HttpStatusCode.NoContent;

            return new ObjectResult(response) { StatusCode = (int)status };
        }

        public async Task<IActionResult> SaveFilesAsync()
        {
            var response = await _requestsRepository.SaveFilesAsync();

            var status = HttpStatusCode.OK;
            if (response == null)
                status = HttpStatusCode.InternalServerError;
            else if (!response.Any())
                status = HttpStatusCode.NotFound;

            return new ObjectResult(response) { StatusCode = (int)status };
        }
    }
}
