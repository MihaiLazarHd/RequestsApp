﻿using Microsoft.AspNetCore.Mvc;
using RequestsApp.Interfaces;
using RequestsApp.Models;
using System;
using System.Collections.Generic;
using System.IO;
using System.Linq;
using System.Threading.Tasks;
using System.Xml.Serialization;

namespace RequestsApp.Repositories
{
    public class RequestsRepository : IRequestsRepository
    {
        private readonly RequestDBContext _context;

        public RequestsRepository(RequestDBContext context)
        {
            _context = context;
        }

        public async Task<List<Request>> ProcessRequestsAsync(List<Request> input)
        {
            try
            {
                var result = new List<Request>();

                await input.ToAsyncEnumerable().ForEachAsync(t =>
                {
                    if (!(_context.Requests.Any(u => u.Index == t.Index)))
                        result.Add(t);
                });

                await _context.Requests.AddRangeAsync(result);

                await _context.SaveChangesAsync();

                return result;
            }
            catch (Exception)
            {
                return null;
            }
        }

        public async Task<List<Request>> SaveFilesAsync()
        {
            var requests = _context.Requests.ToAsyncEnumerable();
            await requests.ForEachAsync(t => WriteXML(t));
            return await requests.ToList();
        }

        public void WriteXML(Request request)
        {
            var writer = new System.Xml.Serialization.XmlSerializer(typeof(Request));

            XmlSerializerNamespaces ns = new XmlSerializerNamespaces();
            ns.Add("", "");

            var startupFolder = Path.Combine(Environment.GetFolderPath(Environment.SpecialFolder.ApplicationData), "xml");
            if (!Directory.Exists(startupFolder))
                Directory.CreateDirectory(startupFolder);

            var dateFolder = Path.Combine(startupFolder, request.Date.ToString("yyyy-MM-dd"));
            if (!Directory.Exists(dateFolder))
                Directory.CreateDirectory(dateFolder);

            var path = Path.Combine(dateFolder, string.Format("{0:00000000}.xml", request.Index.ToString()));
            System.IO.FileStream file = System.IO.File.Create(path);

            writer.Serialize(file, request, ns);
            file.Close();
        }
    }
}
