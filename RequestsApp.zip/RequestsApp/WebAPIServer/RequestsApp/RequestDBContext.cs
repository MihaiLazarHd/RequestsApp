﻿using Microsoft.EntityFrameworkCore;
using Microsoft.EntityFrameworkCore.Design;
using Microsoft.EntityFrameworkCore.Infrastructure;
using RequestsApp.Models;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Reflection;
using System.Threading.Tasks;

namespace RequestsApp
{
    public class RequestDBContext : DbContext
    {
        public virtual DbSet<Request> Requests { get; set; }

        public RequestDBContext(DbContextOptions<RequestDBContext> options) : base(options)
        {
        }
    }

}
