﻿using Microsoft.AspNetCore.Mvc;
using RequestsApp.Models;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace RequestsApp.Interfaces
{
    public interface IRequestsRepository
    {
        Task<List<Request>> ProcessRequestsAsync(List<Request> input);
        Task<List<Request>> SaveFilesAsync();
    }
}
