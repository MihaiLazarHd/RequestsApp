﻿using Newtonsoft.Json;
using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;
using System.Linq;
using System.Threading.Tasks;
using System.Xml.Serialization;

namespace RequestsApp.Models
{
    [XmlRoot("request")]
    public class Request
    {
        [Key]
        [JsonProperty(PropertyName = "ix")]
        [XmlElement("ix")]
        public int Index { get; set; }

        [XmlElement("name")]
        public string Name { get; set; }

        [XmlElement("visits")]
        public int? Visits { get; set; }

        [XmlElement("dateRequested")]
        public DateTime Date { get; set; }

        public bool ShouldSerializeVisits()
        {
            return Visits.HasValue;
        }


    }
}
