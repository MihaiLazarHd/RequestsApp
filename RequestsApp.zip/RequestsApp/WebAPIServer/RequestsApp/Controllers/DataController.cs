﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using Microsoft.AspNetCore.Http;
using Microsoft.AspNetCore.Mvc;
using RequestsApp.Interfaces;
using RequestsApp.Models;

namespace RequestsApp.Controllers
{
    [Route("api/[controller]")]
    [ApiController]
    public class DataController : ControllerBase
    {
        private readonly IRequestsService _requestsService;

        public DataController(IRequestsService requestsService)
        {
            _requestsService = requestsService;
        }

        // POST /api/data
        [HttpPost]
        public async Task<IActionResult> ProcessRequestsAsync(List<Request> input)
        {
            return await _requestsService.ProcessRequestsAsync(input);
        }
    }
}