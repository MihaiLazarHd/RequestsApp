﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using Microsoft.AspNetCore.Http;
using Microsoft.AspNetCore.Mvc;
using RequestsApp.Interfaces;
using RequestsApp.Models;

namespace RequestsApp.Controllers
{
    [Route("api/[controller]")]
    [ApiController]
    public class JobsController : ControllerBase
    {
        private readonly IRequestsService _requestsService;

        public JobsController(IRequestsService requestsService)
        {
            _requestsService = requestsService;
        }
        // GET /api/jobs/saveFiles
        [HttpGet("saveFiles")]
        public async Task<IActionResult> SaveFilesAsync()
        {
            return await _requestsService.SaveFilesAsync();
        }
    }
}